
CREATE TABLE student (
    id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT NOT NULL
);

INSERT INTO student (id, name, age) VALUES (1, 'Pragathi', 22);
INSERT INTO student (id, name, age) VALUES (2, 'Naveen', 20);
INSERT INTO student (id, name, age) VALUES (3, 'Jayasri', 23);
INSERT INTO student (id, name, age) VALUES (4, 'Chander', 21);
